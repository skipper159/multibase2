# Supabase Project: test2

This is a self-hosted Supabase deployment with custom port configurations.

## Port Configuration

- Kong HTTP API: 3838
- Kong HTTPS API: 4281
- PostgreSQL: 4838
- Pooler (Connection Pooler): 4839
- Studio Dashboard: 5838
- Analytics: 6838
