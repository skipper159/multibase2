# Supabase Project: test3

This is a self-hosted Supabase deployment with custom port configurations.

## Port Configuration

- Kong HTTP API: 8100
- Kong HTTPS API: 8543
- PostgreSQL: 9100
- Pooler (Connection Pooler): 9101
- Studio Dashboard: 10100
- Analytics: 11100
