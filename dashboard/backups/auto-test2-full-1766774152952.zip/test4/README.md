# Supabase Project: test4

This is a self-hosted Supabase deployment with custom port configurations.

## Port Configuration

- Kong HTTP API: 8200
- Kong HTTPS API: 8643
- PostgreSQL: 9200
- Pooler (Connection Pooler): 9201
- Studio Dashboard: 10200
- Analytics: 11200
